def main():
    # Input digital number
    digital_number = input("Enter number:")
    a = digital_number

    # Process
    first_number = a[0]
    last_number = a[-1]

    # Output results
    print("The first number is", first_number)
    print("The last number is", last_number)


if __name__ == '__main__':
    main()
