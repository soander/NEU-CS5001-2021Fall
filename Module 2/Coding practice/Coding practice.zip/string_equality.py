def main():
    # Input a word
    word = input()

    # If decision
    if word == "Hi":
        print("Hi, how are you?")

    print("Done")


if __name__ == '__main__':
    main()
